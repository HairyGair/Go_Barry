# ⚡ Quick Setup - Backend at ~/api

## Copy This Into cPanel Terminal

Open **Terminal** in cPanel and paste this:

```bash
# Navigate to api directory (where backend is deployed)
cd ~/api

# Create environment file
cp .env.production .env

# Install dependencies
/opt/cpanel/ea-nodejs20/bin/npm install --production

# Install PM2 process manager
/opt/cpanel/ea-nodejs20/bin/npm install -g pm2

# Start the application
pm2 start server.js --name "gobarry-backend"

# Save PM2 configuration
pm2 save

# Setup auto-restart on reboot
pm2 startup

# Check status
pm2 status

# Test it
curl http://localhost:3001/health

echo ""
echo "✅ Done! Now test in browser:"
echo "https://api.breakdowns.gobarry.co.uk/health"
```

---

## ✅ Expected Output

You should see:

```
┌─────┬──────────────────┬─────────┬─────────┬──────┐
│ id  │ name             │ status  │ restart │ cpu  │
├─────┼──────────────────┼─────────┼─────────┼──────┤
│ 0   │ gobarry-backend  │ online  │ 0       │ 0%   │
└─────┴──────────────────┴─────────┴─────────┴──────┘

{"status":"ok","timestamp":"2025-10-21T...","database":"connected"}
```

**✅ If you see "online" and JSON, it's working!**

Test in browser: **https://api.breakdowns.gobarry.co.uk/health**

---

## 🔧 Quick Commands

### Check Status
```bash
pm2 status
```

### View Logs
```bash
pm2 logs gobarry-backend
```

### Restart
```bash
pm2 restart gobarry-backend
```

### Stop
```bash
pm2 stop gobarry-backend
```

### Start
```bash
pm2 start gobarry-backend
```

---

## ⚠️ If You Get Errors

### "npm: command not found"
Try finding the correct Node.js version:
```bash
ls /opt/cpanel/ea-nodejs*/bin/node
# Use the path shown in the list
```

### "Module not found"
```bash
cd ~/api
/opt/cpanel/ea-nodejs20/bin/npm install --production
pm2 restart gobarry-backend
```

### "Port 3001 already in use"
```bash
pm2 delete gobarry-backend
pm2 start server.js --name "gobarry-backend"
```

### Database connection error
```bash
# Check .env file
cat ~/api/.env | grep DB_

# Test MySQL
mysql -h localhost -u gobarryco_Gair -p
# Password: Turnip1105!!!!!
```

---

## 📊 Full Health Check

```bash
echo "=== PM2 Status ==="
pm2 status

echo ""
echo "=== Local Test ==="
curl http://localhost:3001/health

echo ""
echo "=== Public Test ==="
curl https://api.breakdowns.gobarry.co.uk/health

echo ""
echo "=== Supervisors Endpoint ==="
curl https://api.breakdowns.gobarry.co.uk/api/supervisors
```

---

## ✅ Success = All These Work:

- [ ] `pm2 status` shows **"online"** in green
- [ ] `curl http://localhost:3001/health` returns `{"status":"ok"}`
- [ ] Browser: https://api.breakdowns.gobarry.co.uk/health returns JSON
- [ ] Browser: https://api.breakdowns.gobarry.co.uk/api/supervisors returns array

---

**Just paste the first code block into Terminal and you're done!** 🚀
