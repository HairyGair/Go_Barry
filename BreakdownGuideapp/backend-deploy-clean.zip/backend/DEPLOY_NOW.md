# 🚀 Deploy to cPanel - Quick Start

Since remote MySQL access is blocked by the firewall, we need to deploy the backend to cPanel where it can use `localhost` to connect to the database.

---

## ⚠️ **LEGACY DOCUMENTATION - OUTDATED** ⚠️

**This document describes outdated deployment using Supabase/Render.com.**

**Current Deployment:**
- ✅ Platform: cPanel (self-hosted)
- ✅ Database: MySQL (cPanel)
- ✅ See: `docs/CPANEL_ONLY_DEPLOYMENT_GUIDE.md`
- ✅ Quick: `docs/CPANEL_QUICK_START_10MIN.md`

**Last Updated:** October 27, 2025

---

## ⚡ Fastest Method: Upload via File Manager

### Step 1: Create Deployment Package

**On your Mac, run:**

```bash
cd "/Users/anthony/Go BARRY App/BreakdownGuideapp/backend"
./create-deployment-zip.sh
```

This creates `gobarry-backend.zip` with all necessary files.

---

### Step 2: Upload to cPanel

1. **Log into cPanel** at Pixelish
2. **Open "File Manager"**
3. **Navigate to** `/home/gobarryco/`
4. **Click "Upload"**
5. **Select** `gobarry-backend.zip` from your Mac
6. **Wait for upload to complete**
7. **Right-click the zip file > Extract**
8. **Delete the zip file** after extraction

---

### Step 3: Set Up Node.js App

1. **In cPanel, search for "Setup Node.js App"**
2. **Click "Create Application"**
3. **Configure:**
   - **Node.js version:** 18.x or higher
   - **Application mode:** Production
   - **Application root:** `gobarry-backend-deploy`
   - **Application URL:** `api.gobarry.co.uk` (or your preferred subdomain)
   - **Application startup file:** `server.js`
4. **Click "Create"**
5. **Scroll down and click "Run NPM Install"**
6. **Wait for dependencies to install** (~2 minutes)
7. **Click "Start App"** or **"Restart App"**

---

### Step 4: Test It Works!

**Open your browser and visit:**

```
https://api.gobarry.co.uk/health
```

**Expected response:**
```json
{
  "status": "healthy",
  "database": "mysql",
  "timestamp": "2025-10-16T21:45:00.000Z"
}
```

**Test supervisors endpoint:**
```
https://api.gobarry.co.uk/api/supervisors
```

Should return 16 supervisors!

---

## 🎯 That's It!

Your backend is now running on cPanel with MySQL on localhost!

**Total time:** ~10 minutes

---

## 🔧 If You Need to Make Changes

### Update Code:

1. Edit files locally on your Mac
2. Run `./create-deployment-zip.sh` again
3. Upload new zip to cPanel
4. Extract (overwrite existing files)
5. In "Setup Node.js App", click **"Restart App"**

### View Logs:

1. In "Setup Node.js App"
2. Click on your application
3. Scroll to **"Application Logs"**

---

## 📝 Environment Variables

The `.env` file is already configured in the zip with:

- ✅ `DB_HOST=localhost` (uses cPanel MySQL)
- ✅ `DB_USER=gobarryco_Gair`
- ✅ `DB_NAME=gobarryco_breakdown`
- ✅ JWT_SECRET (production-ready)
- ✅ CORS configured for gobarry.co.uk

---

## ✅ Success Checklist

After deployment:

- [ ] Health check returns "healthy"
- [ ] Can retrieve 16 supervisors
- [ ] Can retrieve 31 breakdowns
- [ ] Authentication works (login/signup)
- [ ] No errors in Application Logs
- [ ] Frontend can connect to API

---

## 🎉 Next Steps

1. **Update frontend** to use `https://api.gobarry.co.uk`
2. **Test all critical features**
3. **Monitor logs for 24 hours**
4. **If stable, suspend Supabase** (saves $25/month)

---

**Need help? Check CPANEL_DEPLOYMENT_GUIDE.md for detailed instructions!**
