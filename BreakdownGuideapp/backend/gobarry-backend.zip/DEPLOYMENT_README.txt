Go BARRY Backend - cPanel Deployment Package
=============================================

INSTALLATION INSTRUCTIONS:

1. Upload this entire folder to your cPanel home directory
2. In cPanel, go to "Setup Node.js App"
3. Create new application:
   - Application root: gobarry-backend-deploy
   - Application startup file: server.js
   - Node.js version: 18.x or higher
4. Click "Run NPM Install"
5. Update .env file with your settings (already configured)
6. Click "Start App"
7. Test at: https://your-domain.com/health

MySQL Configuration:
- Database: gobarryco_breakdown
- Host: localhost (on cPanel)
- User: gobarryco_Gair

For detailed instructions, see CPANEL_DEPLOYMENT_GUIDE.md

Created: $(date)
