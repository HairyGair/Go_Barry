# cPanel Deployment Instructions
Generated: 2025-08-12_19-48-59

## 📦 Package Contents
- **breakdown/** - Main breakdown guide system
- **dashboard/** - Live breakdown monitoring dashboard
- **README.md** - This file

## 🚀 Quick Deploy

### Step 1: Access cPanel
1. Log into your cPanel account
2. Open **File Manager**
3. Navigate to **public_html**

### Step 2: Upload Files
1. Upload the entire **breakdown** folder to public_html
2. Upload the entire **dashboard** folder to public_html
3. Verify file structure:
   ```
   public_html/
   ├── breakdown/
   │   ├── index.html
   │   ├── guide.html
   │   ├── config.js
   │   └── [other files]
   └── dashboard/
       └── index.html
   ```

### Step 3: Set Permissions
- Files: 644
- Directories: 755

### Step 4: Update Domain
Edit **breakdown/config.js** and update if needed:
- Replace backend URL if different
- Adjust any domain-specific settings

## 🔗 Access URLs
After deployment, access your system at:
- **Landing Page**: https://yourdomain.com/breakdown/
- **Breakdown Guide**: https://yourdomain.com/breakdown/guide.html
- **Dashboard**: https://yourdomain.com/dashboard/

## ✅ Testing Checklist
- [ ] Landing page loads correctly
- [ ] Supervisor login works
- [ ] Can start a breakdown assessment
- [ ] Wizards function properly
- [ ] Dashboard shows live data
- [ ] Backend API connection successful

## 🔧 Troubleshooting

### API Connection Issues
1. Check browser console for errors
2. Verify backend is running: https://go-barry.onrender.com/api/health-extended
3. Check CORS settings in .htaccess

### 404 Errors
1. Verify file paths are correct
2. Check .htaccess is uploaded
3. Ensure proper file permissions

### JavaScript Errors
1. Clear browser cache
2. Check console for specific errors
3. Verify config.js is loaded

## 📞 Support
- Backend Status: https://go-barry.onrender.com/api/health-extended
- Documentation: See executive summary and implementation guides

## 🎯 System Features
- 26 Assessment Wizards
- Real-time Breakdown Tracking
- 900+ Fleet Vehicle Database
- Supervisor Authentication
- Pattern Detection
- Complete Audit Trail
- < 3 minute average assessment time

---
Go North East - Leading the future of intelligent bus operations
