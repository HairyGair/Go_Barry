// Breakdown System Configuration
// Generated: 2025-08-12_19-48-59

const CONFIG = {
    // Backend API URL
    BACKEND_URL: 'https://go-barry.onrender.com',
    
    // API Endpoints
    API: {
        // Breakdown tracking endpoints
        START_BREAKDOWN: '/api/breakdowns/start',
        LOG_STEP: '/api/breakdowns/step',
        DIAGNOSE: '/api/breakdowns/diagnose',
        RESOLVE: '/api/breakdowns/resolve',
        LIVE_BREAKDOWNS: '/api/breakdowns/live',
        TODAY_BREAKDOWNS: '/api/breakdowns/today',
        FLEET_HISTORY: '/api/breakdowns/fleet',
        
        // Fleet endpoints
        FLEET_LOOKUP: '/api/fleet',
        
        // Health check
        HEALTH: '/api/health-extended'
    },
    
    // Dashboard settings
    DASHBOARD: {
        REFRESH_INTERVAL: 5000,  // 5 seconds
        OVERDUE_THRESHOLD: 30    // 30 minutes
    },
    
    // Supervisor configuration
    SUPERVISORS: {
        BADGES: ['AW001', 'AC002', 'AG003', 'CF004', 'DH005', 'JD006', 'JP007', 'SG008', 'BP009'],
        ADMIN: ['AG003', 'BP009']
    },
    
    // Priority routes
    PRIORITY_ROUTES: ['X10', 'X21', '21', '56', '307'],
    
    // Depots
    DEPOTS: [
        'Washington',
        'Gateshead',
        'Consett',
        'Hexham',
        'Percy Main',
        'Deptford'
    ],
    
    // System settings
    SYSTEM: {
        VERSION: '2.0',
        ENVIRONMENT: 'production',
        DEBUG: false
    }
};

// Make config globally available
window.CONFIG = CONFIG;
